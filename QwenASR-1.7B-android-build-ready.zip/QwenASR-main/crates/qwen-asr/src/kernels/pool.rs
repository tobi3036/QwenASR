//! Persistent thread pool (mutex+condvar, matching the C reference approach)
//! and the barrier-synchronized parallel region used by the fused decode loop.

use std::cell::Cell;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Condvar, Mutex, OnceLock};
use std::thread;

use super::verbose;

pub(crate) const MAX_THREADS: usize = 16;

struct ThreadPool {
    // Mutex+condvar only used as slow-path fallback when spin-wait misses
    state: Mutex<bool>, // shutdown flag only
    work_cv: Condvar,
    // All dispatch data is lock-free via atomics
    gen_atomic: AtomicU64,
    done_atomic: AtomicUsize,
    fn_ptr_atomic: AtomicUsize,
    fn_call_atomic: AtomicUsize,
    n_threads_atomic: AtomicUsize,
}

static THREAD_POOL: OnceLock<Arc<ThreadPool>> = OnceLock::new();

fn get_pool() -> &'static Arc<ThreadPool> {
    THREAD_POOL.get_or_init(|| {
        Arc::new(ThreadPool {
            state: Mutex::new(false),
            work_cv: Condvar::new(),
            gen_atomic: AtomicU64::new(0),
            done_atomic: AtomicUsize::new(0),
            fn_ptr_atomic: AtomicUsize::new(0),
            fn_call_atomic: AtomicUsize::new(0),
            n_threads_atomic: AtomicUsize::new(1),
        })
    })
}

fn pool_worker(pool: Arc<ThreadPool>, tid: usize, start_gen: u64) {
    // `start_gen` is the generation at spawn time, read by the dispatching
    // thread in `ensure_workers`. A worker spawned after earlier dispatches
    // (set_threads growing the pool mid-process) must not replay the last
    // completed one. Reading the generation here instead raced the next
    // dispatch: a worker first scheduled after its bump took it as already
    // seen, never ran it, and the join waited forever (3-vCPU CI runners).
    let mut last_gen = start_gen;
    loop {
        // Fast path: spin briefly on atomic generation counter
        let mut found = false;
        for _ in 0..512 {
            let gen = pool.gen_atomic.load(Ordering::Acquire);
            if gen != last_gen {
                last_gen = gen;
                found = true;
                break;
            }
            core::hint::spin_loop();
        }

        if !found {
            // Slow path: condvar wait (mutex only protects shutdown flag)
            let mut shutdown = match pool.state.lock() {
                Ok(s) => s,
                Err(p) => p.into_inner(),
            };
            while !*shutdown && pool.gen_atomic.load(Ordering::Relaxed) == last_gen {
                shutdown = match pool.work_cv.wait(shutdown) {
                    Ok(s) => s,
                    Err(p) => p.into_inner(),
                };
            }
            if *shutdown {
                return;
            }
            last_gen = pool.gen_atomic.load(Ordering::Acquire);
        }

        // Read dispatch data from atomics (ordered by gen_atomic Acquire)
        let n_threads = pool.n_threads_atomic.load(Ordering::Relaxed);
        // Workers beyond this dispatch's width (the pool shrank) sit it out:
        // the join counts exactly `n_threads - 1` arrivals, so an extra one
        // would let it return while this worker still runs the closure that
        // lives on the dispatcher's stack.
        if tid >= n_threads {
            continue;
        }
        let fn_ptr = pool.fn_ptr_atomic.load(Ordering::Relaxed) as *const ();
        let fn_call: fn(*const (), usize, usize) =
            unsafe { core::mem::transmute(pool.fn_call_atomic.load(Ordering::Relaxed)) };

        fn_call(fn_ptr, tid, n_threads);
        pool.done_atomic.fetch_add(1, Ordering::Release);
    }
}

static SPAWNED_THREADS: AtomicUsize = AtomicUsize::new(0);

fn ensure_workers(pool: &Arc<ThreadPool>, n_threads: usize) {
    let spawned = SPAWNED_THREADS.load(Ordering::Relaxed);
    if spawned >= n_threads - 1 {
        return;
    }
    let start = spawned + 1;
    let start_gen = pool.gen_atomic.load(Ordering::Acquire);
    for tid in start..n_threads {
        let p = pool.clone();
        thread::Builder::new()
            .name(format!("qwen-worker-{}", tid))
            .spawn(move || pool_worker(p, tid, start_gen))
            .expect("failed to spawn worker thread");
    }
    SPAWNED_THREADS.store(n_threads - 1, Ordering::Relaxed);
}

static THREAD_POOL_THREADS: AtomicUsize = AtomicUsize::new(1);

pub fn set_threads(n: usize) {
    let n = n.clamp(1, MAX_THREADS);
    THREAD_POOL_THREADS.store(n, Ordering::Relaxed);
    if n > 1 {
        let pool = get_pool();
        ensure_workers(pool, n);
    }
    if verbose() >= 2 {
        eprintln!("Thread pool: {} threads", n);
    }
}

thread_local! {
    /// Per-thread override of the effective kernel thread count. `0` means "no
    /// override" (fall back to the global pool count). Set to `1` by the
    /// parallel-segment decode workers so each concurrent segment runs its
    /// kernels single-threaded — `parallel_for`/`parallel_region` then take the
    /// inline `nt == 1` path and never touch the shared global pool, so `K`
    /// segment workers occupy `K` cores without contending on the one pool's
    /// dispatch/barrier machinery (the in-process analogue of L2's independent
    /// processes).
    static THREAD_OVERRIDE: Cell<usize> = const { Cell::new(0) };
}

/// Override the effective kernel thread count for the *current* thread only.
/// Pass `0` to clear. Internal knob for the parallel-segment path; not part of
/// any public API.
pub(crate) fn set_thread_override(n: usize) {
    THREAD_OVERRIDE.with(|c| c.set(n));
}

/// Public variant of [`set_thread_override`]: pin the *calling* thread's kernel
/// parallelism to `n` threads. `n <= 1` makes all kernels run inline on the
/// calling thread (they never dispatch to the shared global pool), which is
/// required when several OS threads drive concurrent [`QwenCtx`](crate::context::QwenCtx)
/// sessions — the global pool supports a single dispatcher at a time. Sessions
/// on the main thread (no override) keep using the full pool as usual.
pub fn set_thread_override_public(n: usize) {
    set_thread_override(n.max(1));
}

pub fn get_num_threads() -> usize {
    let ov = THREAD_OVERRIDE.with(|c| c.get());
    if ov != 0 {
        return ov;
    }
    THREAD_POOL_THREADS.load(Ordering::Relaxed)
}

pub fn get_num_cpus() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
}

#[cfg(target_os = "macos")]
fn sysctl_uint(name: &[u8]) -> Option<usize> {
    debug_assert!(
        name.last() == Some(&0),
        "sysctl name must be NUL-terminated"
    );
    let mut out: i32 = 0;
    let mut size = std::mem::size_of::<i32>();
    let rc = unsafe {
        libc::sysctlbyname(
            name.as_ptr() as *const libc::c_char,
            &mut out as *mut i32 as *mut libc::c_void,
            &mut size,
            std::ptr::null_mut(),
            0,
        )
    };
    if rc == 0 && out > 0 {
        Some(out as usize)
    } else {
        None
    }
}

/// Default kernel thread count when the user passes no `-t N`.
///
/// On Apple Silicon this reads the P-core count (`hw.perflevel0.physicalcpu`)
/// and E-core count (`hw.perflevel1.physicalcpu`) and returns
/// `P + min(E, P + (E - P) / 2)` (integer division): all performance cores plus
/// a bounded slice of the efficiency cores. When `E <= P` this reduces exactly
/// to the older `P + min(E, P)` (= `P + E`), so machines where we have no sweep
/// data — and where the old formula already used all/most cores — are left
/// untouched. When `E > P` it adds P E-cores plus half of the surplus:
/// e.g. M5 Pro 5P/10E → `5 + min(10, 5 + (10 - 5) / 2)` = `5 + min(10, 7)` = 12.
/// The result never exceeds `P + E` (each branch caps the E-core term at `E`).
///
/// Historically this returned P-cores only, on the assumption that efficiency
/// cores always hurt (extra dispatch + memory-bus contention). Round 10 made
/// the multi-token encoder/prefill GEMM phase pool-parallel (`sgemm_nt_pooled`),
/// so `P + min(E, P) = 10` threads then beat the 5-P-core default. Round 11's
/// dynamic work-stealing chunks (`parallel_for_dynamic`) went further: extra
/// E-cores now steal work proportionally instead of straggling on a fixed even
/// slice, which made *more* E-cores profitable. An M5 Pro sweep (t5..t15) put
/// the optimum at 12 threads (t12 −2.8% 3-mode avg vs the t10 default, WER
/// unchanged); t14+ oversubscribes the P+E cores against the process's
/// auxiliary/OS threads and regresses. Hence the new formula lands on 12 here.
/// NOTE: this 12-thread optimum is validated on M5 Pro (5P/10E) only; the shape
/// of the curve (best just below all-cores, cliff at t14+) is the machine-
/// specific part.
///
/// Falls back to the total CPU count on non-macOS or when the perflevel
/// sysctls are unavailable (e.g. Intel Macs), matching the previous behavior.
/// Clamped to [`MAX_THREADS`].
pub fn get_default_threads() -> usize {
    #[cfg(target_os = "macos")]
    {
        if let Some(p) = sysctl_uint(b"hw.perflevel0.physicalcpu\0") {
            let e = sysctl_uint(b"hw.perflevel1.physicalcpu\0").unwrap_or(0);
            return default_threads_formula(p, e).clamp(1, MAX_THREADS);
        }
    }
    get_num_cpus().clamp(1, MAX_THREADS)
}

/// `P + min(E, P + (E - P) / 2)` (integer division), computed with an explicit
/// branch so the `E - P` subtraction can never underflow the unsigned type.
///   E <= P  -> extra = E            -> P + E   (== old `P + min(E, P)`)
///   E >  P  -> extra = P + (E-P)/2  (always <= E, so result <= P + E)
// Only called from the macOS sysctl path (and its unit test); gate it to match
// so non-macOS builds don't see dead code.
#[cfg(any(target_os = "macos", test))]
#[inline]
fn default_threads_formula(p: usize, e: usize) -> usize {
    let extra = if e <= p { e } else { (p + (e - p) / 2).min(e) };
    p + extra
}

/// Run a closure in parallel using the persistent thread pool.
/// The closure takes (thread_id, n_threads).
pub(crate) fn parallel_for<F: Fn(usize, usize) + Send + Sync>(f: F) {
    let n_threads = get_num_threads();
    if n_threads <= 1 {
        f(0, 1);
        return;
    }

    let pool = get_pool();

    // Trampoline: cast *const () back to &F and call it
    fn trampoline<F: Fn(usize, usize) + Send + Sync>(ptr: *const (), tid: usize, nt: usize) {
        let f = unsafe { &*(ptr as *const F) };
        f(tid, nt);
    }

    // Publish dispatch data via atomics (Relaxed OK: gen_atomic Release provides ordering)
    pool.done_atomic.store(0, Ordering::Relaxed);
    pool.fn_ptr_atomic
        .store(&f as *const F as *const () as usize, Ordering::Relaxed);
    pool.fn_call_atomic
        .store(trampoline::<F> as *const () as usize, Ordering::Relaxed);
    pool.n_threads_atomic.store(n_threads, Ordering::Relaxed);
    // Release: ensures all stores above are visible to workers that Acquire gen_atomic
    pool.gen_atomic.fetch_add(1, Ordering::Release);

    // Wake workers that fell through to condvar wait
    // Lock scope is minimal: just notify, no data to write
    {
        let _guard = match pool.state.lock() {
            Ok(s) => s,
            Err(p) => p.into_inner(),
        };
        pool.work_cv.notify_all();
    }

    // Main thread does tid=0
    f(0, n_threads);

    // Wait for workers: spin on atomic done counter, then yield.
    let expected = n_threads - 1;
    let mut backoff = Backoff::new();
    loop {
        if pool.done_atomic.load(Ordering::Acquire) >= expected {
            break;
        }
        backoff.wait();
    }
}

/// Bounded spin, then `sched_yield`.
///
/// A pure `spin_loop()` join is only correct when every participant is actually
/// running. It is not: if the pool has more threads than the OS will schedule
/// — `-t` above the core count, or a cgroup CPU quota below `nproc`, which
/// [`get_num_cpus`] does not read — the joiner burns a core spinning on a
/// worker that cannot run, and the runnable threads it is competing with are
/// the very ones it is waiting for. Measured on a 4-core runner at `-t 16`,
/// decode went from ~4.3 s to ~156 s (~36x) before this backoff.
///
/// The spin phase keeps the fast path free: a normal join resolves in far fewer
/// than `SPIN_LIMIT` iterations and never reaches the syscall.
struct Backoff {
    spins: u32,
    #[cfg(test)]
    yield_calls: usize,
}

impl Backoff {
    /// Long enough to cover a normal join (sub-microsecond), short enough that
    /// a descheduled participant is not waited on for meaningfully longer than
    /// one scheduler quantum.
    const SPIN_LIMIT: u32 = 4096;

    #[inline]
    fn new() -> Self {
        Backoff {
            spins: 0,
            #[cfg(test)]
            yield_calls: 0,
        }
    }

    #[inline]
    fn wait(&mut self) {
        if self.spins < Self::SPIN_LIMIT {
            self.spins += 1;
            core::hint::spin_loop();
        } else {
            // SAFETY: no arguments, no memory effects, always succeeds.
            unsafe {
                libc::sched_yield();
            }
            #[cfg(test)]
            {
                self.yield_calls += 1;
            }
            // Re-arm bounded spinning instead of yielding on every poll of a long stage.
            #[cfg(all(target_os = "macos", target_arch = "aarch64"))]
            {
                self.spins = 0;
            }
        }
    }
}

/// Dynamic (work-stealing) parallel loop over `n_items` fixed-size work items.
/// Every participating pool thread repeatedly grabs the next item index from a
/// shared atomic counter and runs `f(item)`, so faster cores (P-cores) process
/// more items than slower ones (E-cores) instead of each thread owning a fixed
/// even slice and the whole op stalling on the slowest slice. On a heterogeneous
/// P/E-core machine this removes the E-core straggler tax that a static even
/// split pays on every parallel op.
///
/// Work items are FIXED-SIZE and their boundaries do NOT depend on the thread
/// count or on which thread runs which item, so any deterministic per-item
/// computation yields results independent of scheduling. Callers pick the item
/// granularity so there are several items per thread (to allow stealing to
/// balance) while each item is still large enough to amortize one atomic RMW.
///
/// The counter lives on the caller's stack and is captured by the dispatched
/// closure — the same borrow pattern as [`parallel_for`]'s trampoline.
pub(crate) fn parallel_for_dynamic<F: Fn(usize) + Send + Sync>(n_items: usize, f: F) {
    let n_threads = get_num_threads();
    if n_threads <= 1 || n_items <= 1 {
        for i in 0..n_items {
            f(i);
        }
        return;
    }
    let counter = AtomicUsize::new(0);
    parallel_for(|_tid, _nt| loop {
        let i = counter.fetch_add(1, Ordering::Relaxed);
        if i >= n_items {
            break;
        }
        f(i);
    });
}

/// Cache-line-padded wrapper to keep two atomics on separate cache lines and
/// avoid false sharing between the arrival counter and the generation counter.
#[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
#[repr(align(64))]
struct CachePadded<T>(T);

/// Spin barrier for use inside a [`parallel_region`]. Generation-counter based:
/// every participant increments `arrived`; the last arriver resets `arrived`
/// and bumps `generation` (Release), which the spinning participants observe
/// (Acquire). Reusable across many stages within one region. Correct for
/// `nt == 1` (immediate no-op) and for participants whose stage slice was empty
/// (they still call `wait` the same number of times as everyone else).
#[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
pub(crate) struct RegionBarrier {
    arrived: CachePadded<AtomicUsize>,
    generation: CachePadded<AtomicUsize>,
    nt: usize,
}

#[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
impl RegionBarrier {
    #[inline]
    pub(crate) fn new(nt: usize) -> Self {
        RegionBarrier {
            arrived: CachePadded(AtomicUsize::new(0)),
            generation: CachePadded(AtomicUsize::new(0)),
            nt,
        }
    }

    /// Block until all `nt` participants have called `wait`.
    #[inline]
    pub(crate) fn wait(&self) {
        if self.nt <= 1 {
            return;
        }
        let gen = self.generation.0.load(Ordering::Acquire);
        // AcqRel so the arrival RMWs form a release sequence: the last arriver
        // acquires every earlier participant's writes (e.g. tid-0 serial glue),
        // and its `generation` Release then publishes them to all waiters.
        let count = self.arrived.0.fetch_add(1, Ordering::AcqRel) + 1;
        if count == self.nt {
            // Last arriver: reset the counter, then open the gate.
            self.arrived.0.store(0, Ordering::Relaxed);
            self.generation.0.fetch_add(1, Ordering::Release);
        } else {
            // Same oversubscription hazard as the `parallel_for` join, and
            // worse here: a region barrier is hit once per pipeline stage.
            let mut backoff = Backoff::new();
            while self.generation.0.load(Ordering::Acquire) == gen {
                backoff.wait();
            }
        }
    }
}

/// Run a closure once on every worker (plus the calling thread) in a single
/// thread-pool dispatch, keeping the workers resident for the whole closure.
/// The closure receives a shared [`RegionBarrier`] plus `(tid, nt)` and uses
/// `barrier.wait()` to synchronize between dependent stages — so a multi-stage
/// pipeline runs under one dispatch/wake/join cycle instead of one per stage.
#[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
pub(crate) fn parallel_region<F: Fn(&RegionBarrier, usize, usize) + Send + Sync>(f: F) {
    let n_threads = get_num_threads();
    let barrier = RegionBarrier::new(n_threads);
    // Reuse the existing dispatch machinery: one dispatch, and the closure body
    // (with its internal barriers) is what keeps workers spinning across stages.
    parallel_for(|tid, nt| f(&barrier, tid, nt));
}

/// Like [`parallel_region`] but with at most `n` participants: pool workers
/// with `tid >= n` return immediately and the barrier is sized `n`. Used by
/// the single-token decode region, whose per-row / per-head work is assigned
/// to exactly one thread, so its output is identical for any participant
/// count.
#[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
pub(crate) fn parallel_region_n<F: Fn(&RegionBarrier, usize, usize) + Send + Sync>(n: usize, f: F) {
    let n_threads = get_num_threads();
    let n = n.clamp(1, n_threads.max(1));
    if n == n_threads {
        parallel_region(f);
        return;
    }
    let barrier = RegionBarrier::new(n);
    parallel_for(|tid, _nt| {
        if tid < n {
            f(&barrier, tid, n);
        }
    });
}

/// Participants for the fused single-token decode region (R15-3).
///
/// Decode streams ~575 MB of INT8 weights per token through ~280 spin
/// barriers with a static row split, so ONE descheduled participant stalls the
/// whole token. M5 Pro (5P/10E, default 12 threads) with background load:
/// 12 participants measured 4.4–6.0 ms/token and 15 measured ~15 ms/token,
/// against 3.9–4.3 at 8–10. Apple Silicon default: leave two of the configured
/// threads out of the region, never below 8 (one thread per KV group in the
/// attention stage) — 12 → 10. Trade-off: on a fully idle machine 12
/// participants stream ~5–10% more bandwidth (long-context best case), so
/// `QWEN_ASR_DECODE_THREADS=N` overrides for idle-machine benchmarking.
/// Elsewhere: no cap (no data).
#[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
pub(crate) fn decode_region_threads() -> usize {
    static CAP: OnceLock<Option<usize>> = OnceLock::new();
    let nt = get_num_threads();
    let cap = *CAP.get_or_init(|| {
        std::env::var("QWEN_ASR_DECODE_THREADS")
            .ok()
            .and_then(|v| v.trim().parse::<usize>().ok())
            .filter(|&n| n > 0)
    });
    match cap {
        Some(n) => nt.min(n).max(1),
        #[cfg(all(target_os = "macos", target_arch = "aarch64"))]
        None => nt.min(nt.saturating_sub(2).max(8)),
        #[cfg(not(all(target_os = "macos", target_arch = "aarch64")))]
        None => nt,
    }
}

/// Even split of `total` items across `nt` workers; returns this worker's
/// `[start, end)` range (possibly empty).
#[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
#[inline]
pub(crate) fn range_for(tid: usize, nt: usize, total: usize) -> (usize, usize) {
    let chunk = total.div_ceil(nt);
    let start = (tid * chunk).min(total);
    let end = (start + chunk).min(total);
    (start, end)
}

#[cfg(test)]
mod tests {
    use super::{default_threads_formula, Backoff};

    #[test]
    fn backoff_bounds_spinning_and_yield_frequency() {
        let mut backoff = Backoff::new();
        for _ in 0..Backoff::SPIN_LIMIT {
            backoff.wait();
        }
        assert_eq!(
            backoff.yield_calls, 0,
            "short waits must remain syscall-free"
        );
        backoff.wait();
        assert_eq!(
            backoff.yield_calls, 1,
            "long waits must yield to other workers"
        );

        let further_polls = 2 * (Backoff::SPIN_LIMIT + 1);
        for _ in 0..further_polls {
            backoff.wait();
        }
        #[cfg(all(target_os = "macos", target_arch = "aarch64"))]
        assert_eq!(
            backoff.yield_calls, 3,
            "long waits must not become yield storms"
        );
        #[cfg(not(all(target_os = "macos", target_arch = "aarch64")))]
        assert_eq!(
            backoff.yield_calls,
            1 + further_polls as usize,
            "retain the existing oversubscription policy on other platforms"
        );
    }

    #[cfg(any(target_arch = "aarch64", target_arch = "x86_64"))]
    #[test]
    fn region_barrier_publishes_across_delayed_generations() {
        use super::RegionBarrier;
        use std::sync::atomic::{AtomicUsize, Ordering};
        use std::time::Duration;

        let single = RegionBarrier::new(1);
        single.wait();
        single.wait();

        const THREADS: usize = 4;
        const ROUNDS: usize = 16;
        let barrier = RegionBarrier::new(THREADS);
        let slots: [AtomicUsize; THREADS] = std::array::from_fn(|_| AtomicUsize::new(0));
        let mismatches = AtomicUsize::new(0);
        std::thread::scope(|scope| {
            for tid in 0..THREADS {
                let barrier = &barrier;
                let slots = &slots;
                let mismatches = &mismatches;
                scope.spawn(move || {
                    for round in 0..ROUNDS {
                        if tid == round % THREADS {
                            std::thread::sleep(Duration::from_millis(2));
                        }
                        slots[tid].store(round * THREADS + tid + 1, Ordering::Relaxed);
                        barrier.wait();
                        for (owner, slot) in slots.iter().enumerate() {
                            if slot.load(Ordering::Relaxed) != round * THREADS + owner + 1 {
                                mismatches.fetch_add(1, Ordering::Relaxed);
                            }
                        }
                        // Finish all reads before any participant writes the next generation.
                        barrier.wait();
                    }
                });
            }
        });
        assert_eq!(mismatches.load(Ordering::Relaxed), 0);
    }

    /// A worker first scheduled after a dispatch was published must still run
    /// it, and a worker beyond the dispatch width must sit it out.
    #[test]
    fn late_worker_runs_pending_dispatch_and_extra_worker_sits_out() {
        use super::{pool_worker, ThreadPool};
        use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
        use std::sync::{Arc, Condvar, Mutex};
        use std::time::{Duration, Instant};

        static RAN: AtomicUsize = AtomicUsize::new(0);
        fn job(_: *const (), tid: usize, _nt: usize) {
            RAN.fetch_add(1 << (8 * tid), Ordering::Relaxed);
        }
        let pool = Arc::new(ThreadPool {
            state: Mutex::new(false),
            work_cv: Condvar::new(),
            gen_atomic: AtomicU64::new(0),
            done_atomic: AtomicUsize::new(0),
            fn_ptr_atomic: AtomicUsize::new(0),
            fn_call_atomic: AtomicUsize::new(job as *const () as usize),
            n_threads_atomic: AtomicUsize::new(2),
        });
        // The generation `ensure_workers` hands out, then a 2-wide dispatch
        // published before either worker thread has started.
        let start_gen = pool.gen_atomic.load(Ordering::Acquire);
        pool.gen_atomic.fetch_add(1, Ordering::Release);
        let workers = [1, 2].map(|tid| {
            let p = pool.clone();
            std::thread::spawn(move || pool_worker(p, tid, start_gen))
        });
        let t0 = Instant::now();
        while pool.done_atomic.load(Ordering::Acquire) < 1 {
            assert!(
                t0.elapsed() < Duration::from_secs(10),
                "worker 1 skipped the dispatch"
            );
            std::thread::yield_now();
        }
        std::thread::sleep(Duration::from_millis(50)); // room for worker 2 to misbehave
        *pool.state.lock().unwrap() = true;
        pool.work_cv.notify_all();
        for w in workers {
            w.join().unwrap();
        }
        assert_eq!(pool.done_atomic.load(Ordering::Relaxed), 1);
        assert_eq!(
            RAN.load(Ordering::Relaxed),
            1 << 8,
            "only tid 1 joins a 2-wide dispatch"
        );
    }

    #[test]
    fn default_threads_formula_matches_spec() {
        // (a) M5 Pro 5P/10E lands on 12.
        assert_eq!(default_threads_formula(5, 10), 12);
        // (b) E <= P reduces to the old `P + min(E, P)` = `P + E`.
        for (p, e) in [(4, 0), (4, 1), (4, 4), (8, 3), (10, 10), (6, 6)] {
            assert_eq!(default_threads_formula(p, e), p + e, "E<=P: {p}P/{e}E");
        }
        // (c) Never exceeds P + E.
        for p in 1..=16 {
            for e in 0..=24 {
                assert!(default_threads_formula(p, e) <= p + e, "{p}P/{e}E");
            }
        }
        // Spot checks of the E > P branch: P + P + (E-P)/2.
        assert_eq!(default_threads_formula(4, 8), 4 + 6); // 4 + min(8, 4+2)
        assert_eq!(default_threads_formula(2, 8), 2 + 5); // 2 + min(8, 2+3)
        assert_eq!(default_threads_formula(5, 11), 5 + 8); // 5 + min(11, 5+3)
    }
}
