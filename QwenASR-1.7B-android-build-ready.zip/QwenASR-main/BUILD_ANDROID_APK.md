# Build the Qwen3-ASR Android APK

This repository includes a GitHub Actions workflow at `.github/workflows/build-android-apk.yml`.

1. Push/commit the repository to GitHub on the `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**.
4. Select **Run workflow**, choose `main`, and run it.
5. Wait for the workflow to finish successfully.
6. Open the completed run and download the artifact named `qwen3-asr-1.7b-android-arm64`.
7. Extract the downloaded ZIP; it contains `app-release.apk`.

The workflow builds a release APK for 64-bit ARM Android devices. It does not bundle model weights; the app downloads Qwen3-ASR 1.7B when the user chooses to download the model.
