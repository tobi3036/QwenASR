use flutter_rust_bridge::frb;
use qwen_asr::context::QwenCtx;
use qwen_asr::{audio, kernels, transcribe};
use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::sync::Mutex;

/// Engine internals guarded by a single mutex.
///
/// Holds the model context plus a persistent streaming session so that live
/// microphone audio can be pushed incrementally (mirrors the C-FFI
/// `QwenAsrStreamState` in `crates/qwen-asr/src/c_api.rs`).
struct EngineInner {
    ctx: QwenCtx,
    /// Optional ForcedAligner model used for word-level timestamps.
    aligner: Option<QwenCtx>,
    /// Persistent incremental-streaming state (encoder caches, token history).
    stream_state: transcribe::StreamState,
    /// Full accumulated audio buffer — `stream_push_audio` requires the whole
    /// buffer each call and advances an internal cursor over it.
    stream_audio: Vec<f32>,
}

#[frb(opaque)]
pub struct QwenAsrEngine {
    inner: Mutex<EngineInner>,
}

/// Result of a single [`QwenAsrEngine::stream_push`] call.
///
/// `text` is the committed **stable** transcript accumulated so far (same value
/// the push path returned previously). `provisional` is the newest unfixed tail
/// — a lower-confidence hypothesis held back from the stable commit by the
/// rollback / unfixed-chunks window. Render `provisional` distinctly (e.g. grey)
/// and expect it to be revised or promoted to `text` on later pushes. Both are
/// empty when nothing has been produced; `provisional` is empty after finalize.
pub struct StreamPartial {
    pub text: String,
    pub provisional: String,
}

impl QwenAsrEngine {
    /// Load model from a directory path. Returns None if loading fails.
    pub fn load(model_dir: String, n_threads: i32, verbosity: i32) -> Option<QwenAsrEngine> {
        kernels::set_verbose(verbosity);
        let threads = if n_threads <= 0 {
            kernels::get_num_cpus()
        } else {
            n_threads as usize
        };
        kernels::set_threads(threads);
        QwenCtx::load(&model_dir).map(|ctx| QwenAsrEngine {
            inner: Mutex::new(EngineInner {
                ctx,
                aligner: None,
                stream_state: transcribe::StreamState::new(),
                stream_audio: Vec::new(),
            }),
        })
    }

    /// Transcribe a WAV file at the given path.
    pub fn transcribe_file(&self, wav_path: String) -> Option<String> {
        let mut g = self.inner.lock().unwrap();
        transcribe::transcribe(&mut g.ctx, &wav_path)
    }

    /// Transcribe raw PCM f32 samples (16kHz mono).
    pub fn transcribe_pcm(&self, samples: Vec<f32>) -> Option<String> {
        let mut g = self.inner.lock().unwrap();
        transcribe::transcribe_audio(&mut g.ctx, &samples)
    }

    /// Transcribe from a WAV file buffer (bytes).
    pub fn transcribe_wav_buffer(&self, wav_data: Vec<u8>) -> Option<String> {
        let samples = audio::parse_wav_buffer(&wav_data)?;
        let mut g = self.inner.lock().unwrap();
        transcribe::transcribe_audio(&mut g.ctx, &samples)
    }

    /// Set the segment duration in seconds (0 = no segmentation).
    #[frb(sync)]
    pub fn set_segment_sec(&self, sec: f32) {
        let mut g = self.inner.lock().unwrap();
        g.ctx.segment_sec = sec;
    }

    /// Set the forced language. Returns false if the language is invalid.
    ///
    /// A non-empty language turns multilingual auto-detection off. Pass an empty
    /// string to clear the forced language (returns to the default decode path).
    #[frb(sync)]
    pub fn set_language(&self, language: String) -> bool {
        let mut g = self.inner.lock().unwrap();
        g.ctx.set_force_language(&language).is_ok()
    }

    /// Enable/disable opt-in multilingual auto-detection for live streaming.
    ///
    /// When enabled, any forced language is cleared and the decoder re-detects
    /// language from fresh audio at every utterance boundary (silence → EOT),
    /// dropping the past-text carry so a previous utterance's language cannot
    /// drag the next into translation. Session-level: apply before
    /// [`QwenAsrEngine::stream_reset`]; no model reload required.
    #[frb(sync)]
    pub fn set_multilingual(&self, enabled: bool) {
        let mut g = self.inner.lock().unwrap();
        g.ctx.set_multilingual(enabled);
    }

    /// Enable/disable opt-in discrete per-utterance segmentation ("VAD Live")
    /// for live streaming.
    ///
    /// When enabled, the frame-level silence-boundary VAD scan runs and each
    /// detected utterance boundary performs a hard segment reset: the committed
    /// text carry and the encoder window/cache are dropped so the next utterance
    /// decodes from a clean KV/encoder state (discrete segmentation) rather than
    /// a rolling continuation. Independent of [`QwenAsrEngine::set_multilingual`]
    /// — either can drive the scan and their reset actions compose. Session-level:
    /// apply before [`QwenAsrEngine::stream_reset`]; no model reload required.
    #[frb(sync)]
    pub fn set_vad_segment_reset(&self, enabled: bool) {
        let mut g = self.inner.lock().unwrap();
        g.ctx.set_vad_segment_reset(enabled);
    }

    // --------------------------------------------------------------------
    // Word-level timestamps (ForcedAligner)
    // --------------------------------------------------------------------

    /// Load the ForcedAligner model used for word timestamps. Returns false on
    /// failure.
    pub fn load_aligner(&self, aligner_dir: String) -> bool {
        match QwenCtx::load(&aligner_dir) {
            Some(a) => {
                let mut g = self.inner.lock().unwrap();
                g.aligner = Some(a);
                true
            }
            None => false,
        }
    }

    /// Transcribe a window `[start_sec, start_sec + dur_sec)` of a PCM16 WAV
    /// file (read straight from disk, so hours-long files stay cheap on RAM)
    /// and return JSON with per-segment word timestamps. Times in the JSON are
    /// relative to the start of the window.
    pub fn transcribe_wav_window(
        &self,
        wav_path: String,
        start_sec: f64,
        dur_sec: f64,
    ) -> Option<String> {
        let samples = read_wav_window(&wav_path, start_sec, dur_sec)?;
        if samples.is_empty() {
            return None;
        }
        let mut g = self.inner.lock().unwrap();
        let inner = &mut *g;
        let res = transcribe::transcribe_full(
            &mut inner.ctx,
            inner.aligner.as_mut(),
            &samples,
            None,
        )?;
        Some(res.to_json())
    }

    /// Get last transcription performance stats as a formatted string.
    #[frb(sync)]
    pub fn perf_stats(&self) -> String {
        let g = self.inner.lock().unwrap();
        format!(
            "audio={:.1}ms encode={:.1}ms decode={:.1}ms total={:.1}ms tokens={} int8[{}]",
            g.ctx.perf_audio_ms,
            g.ctx.perf_encode_ms,
            g.ctx.perf_decode_ms,
            g.ctx.perf_total_ms,
            g.ctx.perf_text_tokens,
            g.ctx.model().int8_status(),
        )
    }

    // --------------------------------------------------------------------
    // Streaming API (live microphone / real-time incremental transcription)
    // --------------------------------------------------------------------

    /// Reset the streaming session for a new utterance. Clears the accumulated
    /// audio buffer and token history but keeps the loaded tokenizer/model.
    ///
    /// Call once before starting a fresh live-capture session.
    pub fn stream_reset(&self) {
        let mut g = self.inner.lock().unwrap();
        let inner = &mut *g;
        inner.stream_state.reset();
        inner.stream_audio.clear();
    }

    /// Push a new chunk of PCM audio into the live streaming session and return
    /// the current **stable** transcript plus the newest **provisional** tail.
    ///
    /// `samples`: new PCM chunk (f32, 16 kHz, mono, values in -1.0..1.0).
    /// `finalize`: set true on the final push (Stop) to flush remaining audio
    ///             and emit all rollback-buffered tokens.
    ///
    /// Returns a [`StreamPartial`]: `text` is the committed stable transcript
    /// (same as before), `provisional` is the unfixed tail (empty when none, and
    /// always empty after finalize). Runs on a flutter_rust_bridge worker thread,
    /// so the UI stays responsive while a push is in flight.
    pub fn stream_push(&self, samples: Vec<f32>, finalize: bool) -> StreamPartial {
        let mut g = self.inner.lock().unwrap();
        let inner = &mut *g;

        if !samples.is_empty() {
            inner.stream_audio.extend_from_slice(&samples);
        }

        // Disjoint field borrows: ctx (mut), stream_audio (shared),
        // stream_state (mut) are separate fields of EngineInner.
        let _ = transcribe::stream_push_audio(
            &mut inner.ctx,
            &inner.stream_audio,
            &mut inner.stream_state,
            finalize,
        );

        StreamPartial {
            text: inner.stream_state.text(),
            provisional: inner.stream_state.provisional_text(),
        }
    }

    /// Configure the engine's internal streaming chunk size in seconds
    /// (default 8.0). Smaller values emit partial transcripts more frequently
    /// (lower latency) at some throughput cost. This is the primary live-latency
    /// tuning knob and is independent of the mic push-buffer size on the Dart
    /// side.
    #[frb(sync)]
    pub fn set_stream_chunk_sec(&self, sec: f32) {
        if sec > 0.0 {
            let mut g = self.inner.lock().unwrap();
            g.ctx.stream_chunk_sec = sec;
        }
    }

    /// Configure the streaming token rollback window (default 5). Larger values
    /// re-decode more of the tail each chunk for higher stability.
    #[frb(sync)]
    pub fn set_stream_rollback(&self, tokens: i32) {
        if tokens >= 0 {
            let mut g = self.inner.lock().unwrap();
            g.ctx.stream_rollback = tokens;
        }
    }

    /// Configure max new tokens decoded per chunk (default 32).
    #[frb(sync)]
    pub fn set_stream_max_new_tokens(&self, tokens: i32) {
        if tokens > 0 {
            let mut g = self.inner.lock().unwrap();
            g.ctx.stream_max_new_tokens = tokens;
        }
    }

    /// Configure how many leading chunks stay "unfixed" before tokens are
    /// progressively committed to the stable transcript.
    ///
    /// The engine default (99) effectively holds all output until `finalize`,
    /// which for a fast-pushed live stream truncates at `max_new_tokens`. Set a
    /// small value (e.g. 2) for correct progressive incremental streaming.
    #[frb(sync)]
    pub fn set_stream_unfixed_chunks(&self, chunks: i32) {
        if chunks >= 0 {
            let mut g = self.inner.lock().unwrap();
            g.ctx.stream_unfixed_chunks = chunks;
        }
    }

    /// Enable reusing previously decoded text as decoder context across chunks
    /// (prefix rollback). Recommended `true` for live streaming quality; matches
    /// the CLI `--stream` path.
    #[frb(sync)]
    pub fn set_past_text_conditioning(&self, enabled: bool) {
        let mut g = self.inner.lock().unwrap();
        g.ctx.past_text_conditioning = enabled;
    }
}

// ---------------------------------------------------------------------------
// WAV helpers (windowed reads for long files)
// ---------------------------------------------------------------------------

struct WavHdr {
    channels: u16,
    rate: u32,
    data_off: u64,
    data_len: u64,
}

fn read_wav_header(f: &mut File) -> Option<WavHdr> {
    let file_len = f.metadata().ok()?.len();
    let mut hdr = [0u8; 12];
    f.seek(SeekFrom::Start(0)).ok()?;
    f.read_exact(&mut hdr).ok()?;
    if &hdr[0..4] != b"RIFF" || &hdr[8..12] != b"WAVE" {
        return None;
    }
    let mut pos: u64 = 12;
    let mut channels = 0u16;
    let mut rate = 0u32;
    let mut bits = 0u16;
    let mut have_fmt = false;
    loop {
        if pos + 8 > file_len {
            return None;
        }
        f.seek(SeekFrom::Start(pos)).ok()?;
        let mut ch = [0u8; 8];
        f.read_exact(&mut ch).ok()?;
        let size = u32::from_le_bytes([ch[4], ch[5], ch[6], ch[7]]) as u64;
        let body = pos + 8;
        if &ch[0..4] == b"fmt " {
            let mut fm = [0u8; 16];
            f.read_exact(&mut fm).ok()?;
            channels = u16::from_le_bytes([fm[2], fm[3]]);
            rate = u32::from_le_bytes([fm[4], fm[5], fm[6], fm[7]]);
            bits = u16::from_le_bytes([fm[14], fm[15]]);
            have_fmt = true;
        } else if &ch[0..4] == b"data" {
            if !have_fmt || bits != 16 || channels == 0 || rate == 0 {
                return None;
            }
            let avail = file_len.saturating_sub(body);
            let len = if size == 0 || size > avail { avail } else { size };
            return Some(WavHdr {
                channels,
                rate,
                data_off: body,
                data_len: len,
            });
        }
        pos = body + size + (size & 1);
    }
}

/// Read `[start_sec, start_sec + dur_sec)` of a PCM16 WAV as 16 kHz mono f32.
fn read_wav_window(path: &str, start_sec: f64, dur_sec: f64) -> Option<Vec<f32>> {
    let mut f = File::open(path).ok()?;
    let h = read_wav_header(&mut f)?;
    let ch = h.channels as u64;
    let block = ch * 2;
    let total_frames = h.data_len / block;
    let start_frame = (start_sec.max(0.0) * h.rate as f64) as u64;
    if start_frame >= total_frames {
        return Some(Vec::new());
    }
    let want = (dur_sec.max(0.0) * h.rate as f64) as u64;
    let n_frames = want.min(total_frames - start_frame);
    f.seek(SeekFrom::Start(h.data_off + start_frame * block)).ok()?;
    let mut buf = vec![0u8; (n_frames * block) as usize];
    f.read_exact(&mut buf).ok()?;
    let chn = ch as usize;
    let mut mono: Vec<f32> = Vec::with_capacity(n_frames as usize);
    for fr in 0..(n_frames as usize) {
        let mut acc = 0.0f32;
        for c in 0..chn {
            let i = (fr * chn + c) * 2;
            acc += i16::from_le_bytes([buf[i], buf[i + 1]]) as f32 / 32768.0;
        }
        mono.push(acc / chn as f32);
    }
    if h.rate != 16000 {
        Some(audio::resample(&mono, h.rate as i32, 16000))
    } else {
        Some(mono)
    }
}

/// Duration in seconds of a PCM16 WAV file, or -1.0 if it cannot be read.
#[frb(sync)]
pub fn wav_duration_sec(wav_path: String) -> f64 {
    let mut f = match File::open(&wav_path) {
        Ok(f) => f,
        Err(_) => return -1.0,
    };
    match read_wav_header(&mut f) {
        Some(h) => (h.data_len / (h.channels as u64 * 2)) as f64 / h.rate as f64,
        None => -1.0,
    }
}

#[frb(init)]
pub fn init_app() {
    flutter_rust_bridge::setup_default_user_utils();
}
