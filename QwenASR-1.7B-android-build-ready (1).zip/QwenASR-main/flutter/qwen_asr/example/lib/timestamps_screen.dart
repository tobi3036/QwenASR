import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qwen_asr/qwen_asr.dart';

import 'model_manager.dart';

/// Set once the ForcedAligner has been loaded into the engine this session.
bool _alignerLoaded = false;

class _Word {
  final String text;
  final double start;
  final double end;
  const _Word(this.text, this.start, this.end);
}

/// Long-file transcription with word-level timestamps.
///
/// Reads the WAV straight from disk in 5-minute windows (Rust side), aligns
/// every word with the ForcedAligner and exports JSON + SRT.
class TimestampsScreen extends StatefulWidget {
  final QAsrEngine engine;
  const TimestampsScreen({super.key, required this.engine});

  @override
  State<TimestampsScreen> createState() => _TimestampsScreenState();
}

class _TimestampsScreenState extends State<TimestampsScreen> {
  static const double _windowSec = 300.0;

  bool _busy = false;
  bool _cancel = false;
  String _status = 'Idle';
  double _progress = 0;
  String _preview = '';
  String _json = '';
  String _srt = '';
  String _plain = '';
  String _fileBase = 'transcript';

  static String _p2(int v) => v.toString().padLeft(2, '0');

  static String _fmtSrt(double t) {
    final ms = (t * 1000).round();
    final h = ms ~/ 3600000;
    final m = (ms % 3600000) ~/ 60000;
    final s = (ms % 60000) ~/ 1000;
    final r = ms % 1000;
    return '${_p2(h)}:${_p2(m)}:${_p2(s)},${r.toString().padLeft(3, '0')}';
  }

  static String _fmtClock(double t) {
    final total = t.round();
    final h = total ~/ 3600;
    final m = (total % 3600) ~/ 60;
    final s = total % 60;
    return h > 0 ? '$h:${_p2(m)}:${_p2(s)}' : '${_p2(m)}:${_p2(s)}';
  }

  static bool _isCjk(String s) =>
      RegExp(r'[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]').hasMatch(s);

  static String _joinWords(List<_Word> ws) {
    final b = StringBuffer();
    for (var i = 0; i < ws.length; i++) {
      if (i > 0 && !(_isCjk(ws[i - 1].text) && _isCjk(ws[i].text))) {
        b.write(' ');
      }
      b.write(ws[i].text);
    }
    return b.toString();
  }

  static String _buildSrt(List<_Word> words) {
    final cues = <String>[];
    var buf = <_Word>[];
    var idx = 1;
    void flush() {
      if (buf.isEmpty) return;
      cues.add(
        '${idx++}\n${_fmtSrt(buf.first.start)} --> ${_fmtSrt(buf.last.end)}\n'
        '${_joinWords(buf)}\n',
      );
      buf = <_Word>[];
    }

    for (final w in words) {
      if (buf.isNotEmpty) {
        final gap = w.start - buf.last.end;
        final dur = w.end - buf.first.start;
        if (gap > 0.8 || dur > 5.0 || buf.length >= 10) flush();
      }
      buf.add(w);
      if (RegExp(r'[.!?]$').hasMatch(w.text)) flush();
    }
    flush();
    return cues.join('\n');
  }

  Future<bool> _ensureAligner() async {
    if (_alignerLoaded) return true;
    if (!await ModelManager.isAlignerReady()) {
      await ModelManager.downloadAligner(
        onProgress: (p) {
          if (!mounted) return;
          final mb = (p.received / (1024 * 1024)).toStringAsFixed(0);
          final tot = p.total > 0
              ? ' / ${(p.total / (1024 * 1024)).toStringAsFixed(0)}'
              : '';
          setState(() {
            _status = p.done
                ? 'Aligner: ${p.fileName} done'
                : 'Downloading aligner: ${p.fileName} $mb$tot MB';
          });
        },
      );
    }
    if (!mounted) return false;
    setState(() => _status = 'Loading aligner model...');
    final dir = await ModelManager.alignerDir();
    final ok = await widget.engine.loadAligner(dir);
    if (ok) _alignerLoaded = true;
    return ok;
  }

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _cancel = false;
      _status = 'Preparing...';
      _progress = 0;
      _preview = '';
      _json = '';
      _srt = '';
      _plain = '';
    });
    try {
      final ok = await _ensureAligner();
      if (!ok) {
        if (!mounted) return;
        setState(() {
          _status = 'Failed to load the aligner model.';
          _busy = false;
        });
        return;
      }

      final result = await FilePicker.pickFiles(withData: false);
      if (result == null || result.files.isEmpty) {
        if (!mounted) return;
        setState(() {
          _status = 'Pick cancelled';
          _busy = false;
        });
        return;
      }
      final picked = result.files.first;
      final path = picked.path;
      if (path == null) {
        if (!mounted) return;
        setState(() {
          _status = 'Could not get a file path for "${picked.name}"';
          _busy = false;
        });
        return;
      }
      final dur = widget.engine.wavFileDurationSec(path);
      if (dur <= 0) {
        if (!mounted) return;
        setState(() {
          _status =
              'Unsupported file "${picked.name}". Use a 16-bit PCM WAV file.';
          _busy = false;
        });
        return;
      }
      _fileBase = picked.name.replaceAll(RegExp(r'\.[^.]*$'), '');

      widget.engine.setSegmentSec(30.0);

      final words = <_Word>[];
      final segments = <Map<String, dynamic>>[];
      final started = DateTime.now();
      var cursor = 0.0;

      while (cursor < dur - 0.05) {
        if (_cancel) break;
        final remaining = dur - cursor;
        final isLast = remaining <= _windowSec + 1.0;
        final len = isLast ? remaining : _windowSec;
        final json = await widget.engine.transcribeWavWindow(path, cursor, len);
        var nextCursor = cursor + len;
        if (json != null) {
          final m = jsonDecode(json) as Map<String, dynamic>;
          final segs = (m['segments'] as List<dynamic>? ?? <dynamic>[])
              .cast<Map<String, dynamic>>();
          var keep = segs.length;
          if (!isLast && segs.length > 1) {
            // The last segment may be cut at the window edge: drop it and
            // restart the next window where it began.
            keep = segs.length - 1;
            final lastStart = (segs.last['start'] as num).toDouble();
            if (lastStart > 1.0) nextCursor = cursor + lastStart;
          }
          for (var i = 0; i < keep; i++) {
            final seg = segs[i];
            final segWords = <Map<String, dynamic>>[];
            for (final w in (seg['words'] as List<dynamic>? ?? <dynamic>[])) {
              final wm = w as Map<String, dynamic>;
              final s = cursor + (wm['start'] as num).toDouble();
              final e = cursor + (wm['end'] as num).toDouble();
              final t = wm['word'] as String;
              words.add(_Word(t, s, e));
              segWords.add({'word': t, 'start': s, 'end': e});
            }
            segments.add({
              'start': cursor + (seg['start'] as num).toDouble(),
              'end': cursor + (seg['end'] as num).toDouble(),
              'text': seg['text'] as String? ?? '',
              'words': segWords,
            });
          }
        }
        if (nextCursor <= cursor) nextCursor = cursor + len;
        cursor = nextCursor;

        if (!mounted) return;
        final elapsed = DateTime.now().difference(started).inSeconds;
        final tail = segments.length > 12
            ? segments.sublist(segments.length - 12)
            : segments;
        setState(() {
          _progress = (cursor / dur).clamp(0.0, 1.0);
          _status =
              'Transcribing ${_fmtClock(cursor.clamp(0.0, dur))} / '
              '${_fmtClock(dur)} • ${words.length} words • ${elapsed}s elapsed';
          _preview = tail
              .map(
                (s) =>
                    '[${_fmtClock((s['start'] as num).toDouble())}] ${s['text']}',
              )
              .join('\n');
        });
      }

      final plain = segments.map((s) => s['text'] as String).join(' ');
      final out = <String, dynamic>{
        'file': picked.name,
        'duration': dur,
        'word_count': words.length,
        'text': plain,
        'segments': segments,
      };
      if (!mounted) return;
      setState(() {
        _json = const JsonEncoder.withIndent(' ').convert(out);
        _srt = _buildSrt(words);
        _plain = plain;
        _progress = _cancel ? _progress : 1.0;
        _status = _cancel
            ? 'Cancelled (partial result ready)'
            : 'Done: ${words.length} words';
        _busy = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _status = 'Failed: $e';
        _busy = false;
      });
    }
  }

  Future<void> _save(String name, String content) async {
    try {
      final saved = await FilePicker.saveFile(
        fileName: name,
        bytes: Uint8List.fromList(utf8.encode(content)),
      );
      if (!mounted) return;
      setState(() => _status = saved == null ? 'Save cancelled' : 'Saved $name');
    } catch (e) {
      if (!mounted) return;
      setState(() => _status = 'Save failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasResult = _json.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          FilledButton.icon(
            onPressed: _busy ? null : _run,
            icon: const Icon(Icons.timer),
            label: const Text('Pick WAV + Transcribe with Timestamps'),
          ),
          if (_busy)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: OutlinedButton(
                onPressed: () => setState(() => _cancel = true),
                child: const Text('Stop after current window'),
              ),
            ),
          const SizedBox(height: 12),
          if (_busy || _progress > 0) LinearProgressIndicator(value: _progress),
          const SizedBox(height: 8),
          Text('Status: $_status'),
          if (hasResult) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton(
                  onPressed: () => _save('$_fileBase.words.json', _json),
                  child: const Text('Save JSON'),
                ),
                OutlinedButton(
                  onPressed: () => _save('$_fileBase.srt', _srt),
                  child: const Text('Save SRT'),
                ),
                OutlinedButton(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: _plain));
                    if (!mounted) return;
                    setState(() => _status = 'Text copied');
                  },
                  child: const Text('Copy text'),
                ),
              ],
            ),
          ],
          const SizedBox(height: 12),
          const Text('Latest:', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Expanded(
            child: SingleChildScrollView(
              child: SelectableText(_preview.isEmpty ? '(none)' : _preview),
            ),
          ),
        ],
      ),
    );
  }
}
